"""Official flat-upload entrypoint; reconstruct own source tree in /tmp."""
import hashlib
import runpy
import sys
import tempfile
from pathlib import Path

SOURCES={'_atlas_entry.py': ('solution.py', 'd215ddab1515c76c4f8d12e4ffd12b030ab547773dcde76406ccb527a27b958a'), 'atlas___init__.py': ('atlas/__init__.py', '32652b410444c85705834dce792c30cc5dda339daf0ac2c02c7fe8444f6a0cc6'), 'atlas_agent.py': ('atlas/agent.py', '03ac103345a7867eb6beec14f0f889e835d2fc44dde42391c6e668b2d811e413'), 'atlas_budget.py': ('atlas/budget.py', '34fbab619e1076abc1948c38b15f5ad42e30654bbe1efbe2b6de76a67e2b057b'), 'atlas_challenger.py': ('atlas/challenger.py', '4ceea1841a8fc3be10c6bb5074e2ac915494e27ba880b63ef027d858249e2aa1'), 'atlas_context.py': ('atlas/context.py', '892918cfbf6e30658e7d79c27a0ab31a030eb8f60b9caf622656432fd0bfbb71'), 'atlas_contract.py': ('atlas/contract.py', '0a1b4eb3cd6ee3577ab7f8d925a6068422f62ec097c3f8d64a3337cd57caa46f'), 'atlas_encoding.py': ('atlas/encoding.py', 'a6ab154997de9c05bfe8fdf94a3bbe5bcadc1784809f597310580f430f91ca31'), 'atlas_ensemble.py': ('atlas/ensemble.py', 'a15e80d72b73db273ecf1749a01095748cb0ee55fc1b44f98bd65890597f46db'), 'atlas_experiments.py': ('atlas/experiments.py', '67045b00fc5007087d9415a4b187ace0adb86e003004d0470ce60ae480e7c0cf'), 'atlas_expressions.py': ('atlas/expressions.py', '4c80923505ad20eefb6ad3318ee843b66e5c500795d19ac13ab3436ea27f7495'), 'atlas_features.py': ('atlas/features.py', '397f7f17dfe1741d39a6a1f98ba0c4e61f56e1736121980c3ad2443e921ac6bf'), 'atlas_hpo.py': ('atlas/hpo.py', '335d5e0cfa6ca9222f18513281aa7cb69cff746800f43336cdde32b8f10182b4'), 'atlas_ideas.py': ('atlas/ideas.py', 'ce9fc816c490711069c3fb148172408394ff289d2b23f9c552dc5d5467199023'), 'atlas_judge.py': ('atlas/judge.py', '7c4ade373412aa3c436aa633887e78cb3ee5ef9b498f87b4f674bb6fb77ffd23'), 'atlas_metrics.py': ('atlas/metrics.py', '8f7a79069bf727b7b4e7159dea49b52c2c0e71167d43c8efc0c17ce82ecabdb3'), 'atlas_models.py': ('atlas/models.py', '4aab7230554eca3eadb7f8c7aefb196f449088fd9c5b4cb84cc1bc5507c244ed'), 'atlas_orchestration.py': ('atlas/orchestration.py', '2ea429ae9b5f3f21ea960d8418d35fb54b1fc2c96944d8630edc1a7288c8504a'), 'atlas_recipes.py': ('atlas/recipes.py', 'e1088adcf336f3a44f43ed1c75b31a85c80d9989623552153e6219af1a169d70'), 'atlas_research.py': ('atlas/research.py', '2a9c3bc5cd2449864a79b0a55d2f3e70f8c0987245e57204037dc27df26f37b3'), 'atlas_search.py': ('atlas/search.py', 'ca9390e24d05e60a04562a3d49a2af14ab3fc7b1c5f1233854be7a882ee7412f'), 'atlas_submit.py': ('atlas/submit.py', 'ad54b3e74ef475f7ff0e0aa128b0d684fa48a7ee1f51357c2ddf2b0fc9284e48'), 'atlas_task.py': ('atlas/task.py', '3531b82dfd333e8f0c5f3bfbf1461affc8d460ee25550a36720af04e8938c017'), 'atlas_utils.py': ('atlas/utils.py', '6c4737b8442961f0f1cce626cf932a6c05a62026db654030146e01f8b35be737'), 'atlas_validation.py': ('atlas/validation.py', 'ea1fe60525d0fce155774fe05ca0f1ed51aede389d2e3caa672c8279090c2e88'), 'atlas_worker.py': ('atlas/worker.py', 'f0e73fae92a67c512822d5a0fb8816dda6abe7afe992e00129bb4217a7803ab4')}

def main():
    upload=Path(__file__).resolve().parent
    with tempfile.TemporaryDirectory(prefix='atlas-runtime-',dir='/tmp') as temporary:
        runtime=Path(temporary)
        for filename,(relative,expected) in SOURCES.items():
            content=(upload/filename).read_bytes()
            if hashlib.sha256(content).hexdigest()!=expected:
                raise RuntimeError('Source integrity check failed: '+filename)
            target=runtime/relative
            target.parent.mkdir(parents=True,exist_ok=True)
            target.write_bytes(content)
        sys.path.insert(0,str(runtime))
        runpy.run_path(str(runtime/'solution.py'),run_name='__main__')

if __name__=='__main__':
    main()
